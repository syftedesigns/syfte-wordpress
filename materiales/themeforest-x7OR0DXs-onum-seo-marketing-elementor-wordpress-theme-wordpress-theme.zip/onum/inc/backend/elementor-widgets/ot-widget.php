<?php
require_once( get_template_directory() . '/inc/backend/elementor-widgets/heading.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/button.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/service-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/icon-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/icon-box-grid.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/team.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/team-carousel.php' );

require_once( get_template_directory() . '/inc/backend/elementor-widgets/testimonial-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/counter.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/process-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/circle-process.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/progress-bars.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/pricing-table.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/contact-info.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/tab-titles.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/tabs.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/accordions.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/button-video.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/message-box.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/contact-form-7.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/real-number.php' );

require_once( get_template_directory() . '/inc/backend/elementor-widgets/portfolio-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/portfolio-filter.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/post-grid.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/post-carousel.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/social-share.php' );
require_once( get_template_directory() . '/inc/backend/elementor-widgets/countdown.php' );